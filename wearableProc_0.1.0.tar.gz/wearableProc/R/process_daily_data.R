#' Function for calculating results for single individual
#' @param cleaned_df - dataframe ready for processing
#' @param index_dir - the directory for the results
#' @param professor_flag - used for processing professor data (the attributes are different)
#' @export
save_24h_results <- function(cleaned_df, index_dir, professor_flag) {
  unique_dates <- unique(as.Date(cleaned_df$Time))
  num_days <- length(unique_dates)
  for(i in 1:num_days){
    begin_date <- prepare_date(unique_dates[i])
    end_date <- begin_date + (24 * 3600)-60
    require(plyr)
    #Extract 24 hour chunk
    chunk <- subset(cleaned_df, Time >= begin_date &
                      Time < end_date)
    #Make 15 minute splits
    if(nrow(chunk) > 0) {
      splits <- cut(chunk$Time, "15 min")
      if(length(levels(splits)) == 96){
        #Apply median on each split and return the resulting dataframe. Split-Apply-Combine strategy
        chunk15Min <- split_apply_combine(chunk, splits, professor_flag)
        if(nrow(chunk15Min) == 96) {
          #Write the results to file
          make_csv(chunk15Min,index_dir,"15min",begin_date)
          make_extra_measurements(chunk,index_dir,begin_date, professor_flag)
        }
      }
    }
  }
}
