#' Function creating directories, setting the data files, processing them, making daily clustering and validating it
#' @export
execute_script <- function(){
  #Creating dirs, setting data files and processing them
  execute_prof()
  execute_ind()
  #Clustering by day, validating and generating the results of validation
  validate_professor <- clustering(professor_flag = TRUE)
  validate_indiv <- clustering(professor_flag = FALSE)
  validate_plot <- ggplot() +
                   geom_line(aes(x = seq(2,6,1),y=validate_professor, color = "Професор")) +
                   geom_line(aes(x = seq(2,6,1),y=validate_indiv, color = "001")) +
                   guides(color=guide_legend(title = NULL)) +
                   labs(
                   x = "Брой клъстери(k)",
                   y = "Средна стойност на силует индекс",
                   title = "Оценка на дневно клъстериране",
                   caption = "Базирано на данни с времеви интервал: 1 час"
                   )
  #Merging and sorting final data
  merge_sort_files()
}


