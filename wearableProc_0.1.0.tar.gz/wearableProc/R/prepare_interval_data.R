#' Function for preparing the data
#' @param data_file - file with daily data
#' @param begin - String representation of period start hour (e.g "12:00")
#' @param end - String representation of period end hour (e.g "13:00")
#' @return dataframe with values for interval
#' @export
prepare_data <- function(data_file, begin, end) {
  initial_data <- read.csv(file = data_file, header = TRUE, sep = ",")
  data_to_plot <- data.frame(time = initial_data$time, accel_magn = initial_data$accel_magn)
  rm(initial_data)
  date <- as.Date(data_to_plot$time[1])
  begin <- prepare_timehour_char_numeric(begin,FALSE)
  end <- prepare_timehour_char_numeric(end,TRUE)
  data_to_plot$time <- as.POSIXlt(data_to_plot$time,format="%Y-%m-%d %H:%M:%S")
  interval_chunk <- subset(data_to_plot, time$hour >= begin & time$hour < end)
  return(interval_chunk)
}

