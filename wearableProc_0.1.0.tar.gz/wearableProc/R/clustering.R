#' Function for clustering by k means
#' @param professor_flag - used for professor data clustering
#' @return vector of mean values of the silhouette indexes for clustering with k in range 2:6
#' @export
clustering <- function(professor_flag) {
  if(professor_flag) {
    daily_files <- list.files(path = "~/Documents/BasisProc/Professor/1hour",
                              pattern = ".csv",
                              full.names = TRUE)
  } else {
    daily_files <- list.files(path = "~/Documents/BasisProc/001/1hour",
                              pattern = ".csv",
                              full.names = TRUE)
  }
  #Extract the dates
  dates <- list()
  for(i in 1:length(daily_files)) {
    dates[[i]] <- str_sub(basename(daily_files[i]),1,-5)
  }
  #Creating the matrix of daily hourly distributed accel_magn values
  clustering_matrix <- matrix(nrow = length(daily_files), ncol = 24)
  rownames(clustering_matrix) <- dates
  colnames(clustering_matrix) <- 0:23
  for(i in 1:length(daily_files)) {
    data <- read.csv(file = daily_files[i], header = TRUE, sep = ",")
    #Creating daily profile with hourly distributed values
    daily_profile <- data$accel_magn
    #Add the daily profile to the matrix
    clustering_matrix[i,] <- daily_profile
  }
  #Scaling the matrix
  scaled_mat <- scale(clustering_matrix)
  #List of resulting clustering objects
  resulting_clusters <- list()
  #Begin clustering
  min_n_clust <- 2
  max_n_clust <- 6
  for(i in min_n_clust:max_n_clust){
    #For 2 clusters we choose workday and weekend day for initial centers
    if(i==2) {
      #Creating matrix with days to be used as initial centers for the clustering
      my_centers <- matrix(nrow = 2, ncol = 24)
      if(professor_flag) {
        my_centers[1,] <- scaled_mat["2014-09-03",]
        my_centers[2,] <- scaled_mat["2015-02-22",]
      } else{
        my_centers[1,] <- scaled_mat["2014-11-10",]
        my_centers[2,] <- scaled_mat["2015-04-11",]
      }
      resulting_clusters[[i-1]] <- kmeans(scaled_mat,centers = my_centers)
    } else {
      resulting_clusters[[i-1]] <- kmeans(scaled_mat,i,iter.max = 20)
    }
  }
  clust_list_init <- min_n_clust - 1
  clust_list_end <- max_n_clust - 1
  #Validate the clustering with Silhouette Index
  si_mean <- c()
  for(i in 1:5) {
    si <- silhouette(resulting_clusters[[i]]$cluster, dist(scaled_mat,"euclidean"))
    si_mean[i] <- mean(si[,3])
  }
  return(si_mean)
}

