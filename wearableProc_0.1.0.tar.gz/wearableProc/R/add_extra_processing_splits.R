#' Extra measurements to be done at processing stage
#' @param chunk - the daily chunk of data
#' @param index_dir - the directory for the results
#' @param begin_date - the date of the data at chink
#' @param professor_flag - used for processing professor data (the attributes are different)
#' @export
make_extra_measurements<- function(chunk,index_dir,begin_date, professor_flag){
  #Make 10 minute splits
  splits <- cut(chunk$Time, "10 min")
  #Apply median on each split and return the resulting dataframe. Split-Apply-Combine strategy
  chunk10Min <- split_apply_combine(chunk,splits, professor_flag)
  #Write the results to file
  make_csv(chunk10Min,index_dir,"10min",begin_date)
  #Make 30 minute splits
  splits <- cut(chunk$Time, "30 min")
  #Apply median on each split and return the resulting dataframe. Split-Apply-Combine strategy
  chunk30Min <- split_apply_combine(chunk, splits, professor_flag)
  #Write the results to file
  make_csv(chunk30Min,index_dir,"30min",begin_date)
  #Make 1 hour splits
  splits <- cut(chunk$Time, "1 hour")
  #Apply median on each split and return the resulting dataframe. Split-Apply-Combine strategy
  chunk1Hour <- split_apply_combine(chunk, splits, professor_flag)
  #Write the results to file
  make_csv(chunk1Hour,index_dir,"1hour",begin_date)
}

