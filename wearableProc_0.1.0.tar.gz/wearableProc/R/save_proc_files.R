#' Save file in proper dir
#' @param data_to_save - dataframe to be saved
#' @param index_dir - the path to the directory of the individual
#' @param splits - time splits for aggregation (10min,15min etc.)
#' @param current_date - date of measure
#' @export
make_csv <- function(data_to_save, index_dir, splits, currentDate) {
  #Create subdir for split period and fix path
  time_split_dir <- paste(index_dir,splits,"/", sep = "")
  if(!dir.exists(time_split_dir)) {
    dir.create(path = time_split_dir,
               showWarnings = TRUE,
               recursive = TRUE,
               mode = "0777")
  }
  currentDate <- as.Date.character(currentDate)
  write_file <- paste(time_split_dir, currentDate,".csv", sep = "")
  write.csv(data_to_save,file = write_file, row.names = FALSE)
}
