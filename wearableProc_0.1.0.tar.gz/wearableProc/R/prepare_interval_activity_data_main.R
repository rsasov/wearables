#' Main function to be executed
#'
#' The function generates graphics in django project static folder ready for render
#' @param start - string representation of period start hour (e.g "12:00")
#' @param end - string representation of period end hour (e.g "13:00")
#' @param interval - String representation for time splits (e.g "10min","15min","30min","1hour")
#' @export
prepare_interval_activity_data <- function(start,end,interval) {
  Sys.setenv(TZ ="UTC")
  dir_interval <- set_interval(interval)
  base_dfs_dir <- "~/Documents/BasisProc"
  data_prof <- prepare_professor_data_csv(start,end,dir_interval,base_dfs_dir)
  data_ind <- prepare_individual_data_csv(start,end,dir_interval,base_dfs_dir)
  plot_save(data_prof,start,end,interval,id="Professor")
  plot_save(data_ind,start,end,interval,id="001")
}


