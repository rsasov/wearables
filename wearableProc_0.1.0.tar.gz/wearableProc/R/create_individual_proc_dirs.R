#' Function for creating separate directory for each individual
#' @param data_file - initial dataframe
#' @param professor_flag - used for processing professor data (the directories are different)
#' @return The path of the directory where the processed data will be saved
#' @export
create_dirs <- function(data_file, professor_flag){
  if(professor_flag == FALSE) {
    index <- str_extract(basename(data_file), "\\d+\\w")
    index_dir <- paste("/home/rsas/Documents/BasisProc/",index,"/", sep = "")
  } else {
    index_dir <- "/home/rsas/Documents/BasisProc/Professor/"
  }
  if(!dir.exists(index_dir)) {
    dir.create(path = index_dir,
               showWarnings = TRUE,
               recursive = TRUE,
               mode = "0777")
  }
  return(index_dir)
}
