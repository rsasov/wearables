#' Function for processing the individuals data
#' @export
execute_ind <- function(){
  #Load all the files with data
  data_files <- list.files(path = "~/Documents/TU/BachelorThesis/wearables/Basis_Watch_Data",
                           pattern = "*.csv",
                           full.names = TRUE)
  files_num <- length(data_files)
  for(i in 1){
    #Creating result directories
    dir <- create_dirs(data_files[i], professor_flag = FALSE)
    #Clean data frame
    cleaned_df <- create_df(data_files[i], professor_flag = FALSE)
    #Process the data and save results
    save_24h_results(cleaned_df, dir, professor_flag = FALSE)
  }
}
