#' Generate and save activity profiles for provided interval
#' @param list_results - list of dataframes to be plotted
#' @param start - string representation of period start hour (e.g "12:00")
#' @param end - string representation of period end hour (e.g "13:00")
#' @param interval - String representation for time splits (e.g "10min","15min","30min","1hour")
#' @export
plot_save <- function(df,start,end,interval,id) {
  result_df <- read.csv(file = "~/Documents/BasisProc/Professor/1hour/2014-05-24.csv", header = TRUE, sep = ",")
  result_df <- data.frame(time = result_df$time, accel_magn = result_df$accel_magn)
  new_plot <-
    ggplot(result_df, aes(as.POSIXlt(time)$hour, accel_magn)) +
    geom_col() +
    geom_point() +
    scale_x_continuous(breaks = seq(0, 23, 1)) +
    theme_bw() +
    labs(
      x = "Час от деня",
      y = "Активност",
      title = paste("Активност за индивид #", id, " за въведения интервал",sep = ""),
      caption = paste(
        "Базирано на данни с времеви интервал: ",
        interval,
        sep = " "
      )
    )
  file_name <-
    paste("~/Documents/django-rsas/wearables/wearablesapp/static/images/",
          id,
          ".png",
          sep = "")
  ggsave(file_name)
}
