#' Generate and save activity profiles for provided interval
#' @param data - dataframe to be plotted
#' @param start - string representation of period start hour (e.g "12:00")
#' @param end - string representation of period end hour (e.g "13:00")
#' @param interval - String representation for time splits (e.g "10min","15min","30min","1hour")
#' @param id - string representing individual (e.g "Professor","001")
#' @export
plot_save <- function(data,start,end,interval,id) {
  interval <- as.numeric(interval)
  splits <- list("10 минути","15 минути","30 минути","1 час")
  require(ggplot2)
  require(scales)
  new_plot <-
    ggplot(data, aes(data$time, accel_magn)) +
    geom_col(color = "royal blue") +
    geom_point() +
    scale_x_datetime(breaks = ("1 hour"), date_labels = ("%H")) +
    theme_bw() +
    labs(
      x = "Час от деня",
      y = "Активност",
      title = paste("Активност за индивид #", id, " за въведения интервал",sep = ""),
      caption = paste(
        "Базирано на данни с времеви интервал: ",
        splits[[interval]],
        sep = ""
    )
    )
  file_name <-
    paste("~/Documents/django-rsas/wearables/wearablesapp/static/images/",
          id,
          ".png",
          sep = "")
  ggsave(file_name, width = 8, height = 8, dpi = 100, units = "in")
}
