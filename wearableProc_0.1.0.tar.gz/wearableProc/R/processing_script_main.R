#' Main function
#' @export
run_script <- function() {
  start_time <- Sys.time()
  Sys.setenv(TZ='UTC') #Need for removing the daylight saving time dependency
  execute_script()
  end_time <- Sys.time()
  print("Elapsed Time : ")
  print(end_time - start_time)
}
