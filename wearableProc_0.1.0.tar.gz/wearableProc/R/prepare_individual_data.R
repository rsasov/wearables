#' Function for generating the data for individual
#' @param start - string representation of period start hour (e.g "12:00")
#' @param end - string representation of period end hour (e.g "13:00")
#' @param interval - String representation for time splits (e.g "10min","15min","30min","1hour")
#' @param base_dir - Directory with data files
#' @return dataframe for the interval of begin and end hours for individuals data
#' @export
prepare_individual_data_csv <- function(start,end,interval,base_dir){
  data_files = list.files(path = paste(base_dir,"001",interval, sep = "/"),
                          pattern = ".csv",
                          full.names = TRUE)
  num_data_files <- length(data_files)
  id <- sample(1:num_data_files,1, replace = TRUE)
  data <- prepare_data(data_files[id],start,end)
  return(data)
}
