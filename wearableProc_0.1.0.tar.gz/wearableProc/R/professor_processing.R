#' Function for processing the professors data
#' @export
execute_prof <- function(){
  #Load all the files with data
  prof_data <- list.files(path = "~/Documents/TU/BachelorThesis/wearables/Subject1_rawdata/Subject1_rawdata/Basis/MPS_B1",
                          pattern = "*.csv",
                          full.names = TRUE)
  num_prof_data <- length(prof_data)
  for(i in 1:num_prof_data) {
    #Creating result directories
    dir <- create_dirs(prof_data[i], professor_flag = TRUE)
    #Clean data frame
    cleaned_df <- create_df(prof_data[i], professor_flag = TRUE)
    #Process the data and save results
    save_24h_results(cleaned_df, dir, professor_flag = TRUE)
  }
}
