#' Setting the interval in correct format for directories
#' @param interval - String representation coming from radio in form (e.g "10 мин.")
#' @return formatted interval string
#' @export
set_interval <- function(interval){
  interval = 3
  final = switch(
    interval,
    "10min",
    "15min",
    "30min",
    "1hour"
  )
}
