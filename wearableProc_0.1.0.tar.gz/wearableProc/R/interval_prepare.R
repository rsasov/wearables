#' Setting the interval in correct format for directories
#' @param interval - String representation coming from radio in form (e.g "10 мин.")
#' @return formatted interval string
#' @export
set_interval <- function(interval){
  index <- str_extract(interval,"[0-9]+")
  index <- as.numeric(index)
  if(index == 1) {
    final <- "1hour"
  } else {
    final <- paste(index,"min",sep = "")
  }
  return(final)
}
