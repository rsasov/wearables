#' Function for placing the generated files from working dir to the proper dir for results
#' @export
move_to_dirs <- function() {
  data_files <- list.files(path = "~/",
                           pattern = "*.csv",
                           full.names = TRUE)
  num_files <- length(data_files)
  for(i in 1:num_files) {
    if(str_detect(data_files[i],"10min")){
      new_path <- "~/Documents/Results/10min/"
    }
    if(str_detect(data_files[i],"15min")){
      new_path <- "~/Documents/Results/15min/"
    }
    if(str_detect(data_files[i],"30min")){
      new_path <- "~/Documents/Results/30min/"
    }
    if(str_detect(data_files[i],"1hour")){
      new_path <- "~/Documents/Results/1hour/"
    }
    file.rename(from = paste("~/",basename(data_files[i]),sep=""),
                to = paste(new_path, basename(data_files[i]), sep = ""))
  }
}
