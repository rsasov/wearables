#' Function for merging files and sorting them by datetime
#' @param files - files to be merged
#' @param add_individual_id_flag - used for including the index of the individual to the name of the result file
#' @return The merged and sorted dataframe
#' @export
merge_files <- function(files,add_individual_id_flag) {
  num_files <- length(files)
  for (k in 1:num_files) {
    if (k == 1) {
      result_df <-
        read.csv(file = files[k],
                 header = TRUE,
                 sep = ",",
                 row.names = NULL)
      if(add_individual_id_flag){
        ind_id <- basename(files[k])
        result_df$individual_id <- word(ind_id,1,sep = fixed("_"))
      }
    } else {
      df_add <-
        read.csv(file = files[k],
                 header = TRUE,
                 sep = ",",
                 row.names = NULL)
      if(add_individual_id_flag){
        ind_id <- basename(files[k])
        df_add$individual_id <- word(ind_id,1,sep = fixed("_"))
      }
      result_df <- rbind(result_df, df_add)
    }
  }
  #Sort data
  result_df<-result_df[order(result_df$time),]
  return(result_df)
}
