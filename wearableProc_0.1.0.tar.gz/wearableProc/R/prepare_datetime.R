#' Prepare date and set time in POSIXct format
#' @param date_to_prepare - date to be prepared for starting date for the aggregation step
#' @return POSIXct object with generated date with time 00:00:01
#' @export
prepare_date <- function(date_to_prepare){
  string_date_time <- paste(as.character(date_to_prepare),"00:00:01",sep = " ") # Time 00:00:00 cause problems
  result_date_time <- as.POSIXct(string_date_time, format="%Y-%m-%d %H:%M:%S", tzone = "UTC")
  return(result_date_time)
}
