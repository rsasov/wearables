#' Function for preparing the time base on the parameters for begin and end
#' @param time_hour - String representation of period hour (e.g "12:00")
#' @param end_flag - Flag for end period used for validation
#' @return numeric representation of the hour
#' @export
prepare_timehour_char_numeric<- function(time_hour, end_flag) {
  time_hour <- substr(time_hour, start = 1, stop = 2)
  #Check if hour value 0 and set it to 24
  if(end_flag & time_hour=="00") {
    time_hour="24"
  }
  time_hour <- as.numeric(time_hour)
  return(time_hour)
}
