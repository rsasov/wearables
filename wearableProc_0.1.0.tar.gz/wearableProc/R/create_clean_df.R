#' Function for creating a clean data frame ready for processing
#' @param data_file - initial dataframe
#' @param professor_flag - used for processing professor data (the attributes are different)
#' @return Cleaned dataframe
#' @export
create_df <- function(data_file, professor_flag) {
  init_data <- read.csv(file = data_file, header = TRUE, sep = ",")
  if(professor_flag){
    work_data <- data.frame(Time = init_data$time, hr = init_data$hr, accel_magn = init_data$accel_magnitude, skin_temp = init_data$skin_temp, activity = init_data$activity)
  } else {
    work_data <- data.frame(Time = init_data$time, hr = init_data$hr, accel_magn = init_data$accel_magnitude, skin_temp = init_data$skin_temp)
  }
  work_data <- work_data[!is.na(work_data$accel_magn),]
  work_data$Time <- as.POSIXct(work_data$Time, format='%Y-%m-%d %H:%M:%S', tzone = "UTC")
  rm(init_data)
  return(work_data)
}
