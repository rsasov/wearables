#' Function for merging, sorting and placing the final processed results in dirs
#' @export
merge_sort_files <- function() {
  if(!dir.exists("~/Documents/Results/10min/")) {
    dir.create(path = "~/Documents/Results/10min/",
               showWarnings = TRUE,
               recursive = TRUE,
               mode = "0777")
  }
  if(!dir.exists("~/Documents/Results/15min/")) {
    dir.create(path = "~/Documents/Results/15min/",
               showWarnings = TRUE,
               recursive = TRUE,
               mode = "0777")
  }
  if(!dir.exists("~/Documents/Results/30min/")) {
    dir.create(path = "~/Documents/Results/30min/",
               showWarnings = TRUE,
               recursive = TRUE,
               mode = "0777")
  }
  if(!dir.exists("~/Documents/Results/1hour/")) {
    dir.create(path = "~/Documents/Results/1hour/",
               showWarnings = TRUE,
               recursive = TRUE,
               mode = "0777")
  }
  #Iterate through 001-043
  df_dirs <- list.dirs(path = "~/Documents/BasisProc",
                       full.names = TRUE,
                       recursive = FALSE)
  num_dirs <- length(df_dirs)
  for (i in 1:num_dirs) {
    #Iterate through 10min-15min
    measurements_dirs <- list.dirs(
      path = df_dirs[i],
      full.names = TRUE,
      recursive = FALSE
    )
    num_measurements_dirs <- length(measurements_dirs)
    if (num_measurements_dirs > 1) {
      for (j in 1:num_measurements_dirs) {
        #iterate through files
        daily_data_files <-
          list.files(
            path = measurements_dirs[j],
            full.names = TRUE,
            recursive = FALSE
          )
        result_df <- merge_files(daily_data_files,add_individual_id_flag = FALSE)
        #In need of merged dataframes uncomment below
        write.csv(result_df, file = paste(
          basename(df_dirs[i]),
          "_",
          basename(measurements_dirs[j]),
          ".csv",
          sep = ""
        ), row.names = FALSE)
      }
    }
  }
  move_to_dirs()
}
