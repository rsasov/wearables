#' Mode function for string data
#' @param v list of values
#' @return The most frequent string
#' @export
getmode <- function(v) {
  uniqv <- unique(v)
  uniqv[which.max(tabulate(match(v, uniqv)))]
}
