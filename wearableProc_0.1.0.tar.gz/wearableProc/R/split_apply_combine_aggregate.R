#' Function implementing the aggregating step
#' @param chunk - subset to be processed
#' @param splits - time splits used for processing
#' @param professor_flag - used for processing professor data (the attributes are different)
#' @return Result dataframe after processing
#' @export
split_apply_combine <- function(chunk, splits, professor_flag) {
  if(professor_flag) {
    result <- ddply(chunk,
                    .(time = splits),
                    summarise,
                    accel_magn = median(accel_magn, na.rm = TRUE),
                    hr = median(hr, na.rm =TRUE),
                    skin_temp = median(skin_temp, na.rm = TRUE),
                    activity = getmode(activity),
                    .progress = "text")
  } else {
    result <- ddply(chunk,
                    .(time = splits),
                    summarise,
                    accel_magn = median(accel_magn, na.rm = TRUE),
                    hr = median(hr, na.rm =TRUE),
                    skin_temp = median(skin_temp, na.rm = TRUE),
                    .progress = "text")
  }
  return(result)
}
